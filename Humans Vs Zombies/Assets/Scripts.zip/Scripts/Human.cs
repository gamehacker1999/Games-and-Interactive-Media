﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//Represents the human class and the behaviours for humans
//Inherits from the vehicle class
//Author - Shubham Sachdeva
//Restrictions - NONE
public class Human : Vehicle
{

    //Fields
    List<GameObject> zombies;
    GameObject sphere;

	// Use this for initialization
	void Start ()
    {
        base.Start();
    }
	
	// Update is called once per frame
	void Update ()
    {
        base.Update();

        //Toggle debug lines with D
        if (Input.GetKeyDown(KeyCode.D))
        {
            drawDebug = !drawDebug;
        }
    }

    /// <summary>
    /// Calculates the steering forces
    /// </summary>
    public override void  CalcSteeringForces()
    {
        sphere = GameObject.Find("AgentManager").GetComponent<AgentManager>().sphereReference;
        zombies = GameObject.Find("AgentManager").GetComponent<AgentManager>().zombies;
        

        //Vector that represents the total steering force
        Vector3 ultimateForce =Vector3.zero;

        //Seek the purple sphere
        ultimateForce += Seek(sphere);

        //Flee the zombie
        for(int i = 0;i<zombies.Count;i++)
        {
            //Flee the zombie when it is less than 5 units away
            if((transform.position-zombies[i].transform.position).sqrMagnitude<25)
            {
                ultimateForce += Flee(zombies[i]);
            }

            //Else slow down
            else
            {
                ApplyFriction(0.9f);
            }

        }

        //Staying within the terrain
        bool stayInPark = StayInPark();

        //If the human hits the boundry, seek the center
        if(stayInPark)
        {
            Terrain terrain = Terrain.activeTerrain;
            Vector3 center = terrain.terrainData.bounds.center;
            ultimateForce += Seek(center);

        }

        //Avoiding obstacles
        ultimateForce += ObstacleAvoidance();

        //Scaling the ultimate force by max speed
        ultimateForce *= maxSpeed;

        ultimateForce.y = 0;

        //Applying this force
        ApplyForce(ultimateForce);

    }

    /// <summary>
    /// Human stays in the terrain
    /// </summary>
    /// <returns></returns>
    bool StayInPark()
    {
        //Getting the bounds of the terrain
        Terrain terrain = Terrain.activeTerrain;
        float maxXPos = terrain.terrainData.bounds.max.x;
        float maxZPos = terrain.terrainData.bounds.max.z;
        float minXpos = terrain.terrainData.bounds.min.x;
        float minZPos = terrain.terrainData.bounds.min.z;

        //If it hits the left edge
        if (vehiclePosition.x < minXpos)
        {
            return true;
        }

        //Hits the right edge
        if (vehiclePosition.x > maxXPos)
        {
            return true;

        }

        //If it hits the top
        if (vehiclePosition.z > maxZPos)
        {
            return true;

        }
    
        //If it hits the bottom
        if (vehiclePosition.z < minZPos)
        {
            return true;

        }

        return false;


    }
    
    //Method to show the debug lines
    private void OnRenderObject()
    {

        //If the user wants to see the debug lines
        if (drawDebug)
        {
            //Forward Line
            debugGreen.SetPass(0);

            GL.Begin(GL.LINES);
            GL.Vertex(transform.position); //Starting end point
            GL.Vertex(transform.position + transform.forward * 10); //Finishing end point
            GL.End();

            //Right Line
            debugBlue.SetPass(0);

            GL.Begin(GL.LINES);
            GL.Vertex(transform.position);
            GL.Vertex(transform.position + transform.right * 10);
            GL.End();
        }


    }
}
