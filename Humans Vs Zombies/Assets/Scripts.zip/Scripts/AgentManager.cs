﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//Class to manage all the agents in the scene
//Author - Shubham Sachdeva
//Restrictions - NONE
public class AgentManager : MonoBehaviour {

    //Fields
    public GameObject zombie;
    public GameObject human;
    public GameObject purpleSphere;

    public List<GameObject> zombies;
    public List<GameObject> humans;
    public List<GameObject> obstacles;
    public GameObject sphereReference;

	// Use this for initialization
	void Start ()
    {

        zombies = new List<GameObject>();
        humans = new List<GameObject>();

        //Initializing the humans, zombies and the sphere
        for(int i =0;i<5; i++)
        {
            zombies.Add(InstantiateObject(zombie));
            humans.Add(InstantiateObject(human));
        }

        //Instantiating something that the humans can seek
        sphereReference = InstantiateObject(purpleSphere);
		
	}
	
	// Update is called once per frame
	void Update ()
    {
        for(int i = 0;i<humans.Count;i++)
        {
            //Move the sphere so that the humans are always mobile
            //Happens when they are close to the sphere
            if((sphereReference.transform.position-humans[i].transform.position).sqrMagnitude<10)
            {
                Destroy(sphereReference);
                sphereReference = InstantiateObject(purpleSphere);
            }

        }
		
	}

    /// <summary>
    /// Method to intantiate an object on the terrain
    /// </summary>
    /// <param name="agent">The agent being instantiated</param>
    /// <returns></returns>
    public GameObject InstantiateObject(GameObject agent)
    {

        //Getting the terrain bounds
        Terrain terrain = Terrain.activeTerrain;
        float maxXPos = terrain.terrainData.bounds.max.x;
        float maxZPos = terrain.terrainData.bounds.max.z;
        float minXpos = terrain.terrainData.bounds.min.x;
        float minZPos = terrain.terrainData.bounds.min.z;

        //Getting the x and z position
        float xPos = Random.Range(minXpos, maxXPos);
        float zPos = Random.Range(minZPos, maxZPos);

        //finding the y position
        float yPos = terrain.SampleHeight(new Vector3(xPos, 0, zPos));
        yPos += agent.transform.localScale.y/2;

        //Instantiating
        return Instantiate(agent, new Vector3(xPos, yPos, zPos), Quaternion.identity);

    }

}
